function [ currentNet, currentV] = SoftweightedSR(data, lambda)

% load C;data=C;clear C;

       [T, nROI] = size(data);
       currentV = zeros(T,1);
       V0 = (1/T)*eye(T);
%        a=rand(1,T);
%        b=sum(a);
%        c=a/b;
%        V0=diag(c);
% load V0;
       K = 100;%��������
%        lambda=0.0001*2;

       currentNet = zeros(nROI,nROI);
            
                    opts=[];
                    opts.init = 2;
                    opts.tFlag = 5;  % termination criterion
                    opts.nFlag = 0;  % normalization option: 0-without normalization
                    opts.rFlag = 0;   % regularization % the input parameter 'rho' is a ratio in (0, 1)
                    opts.rsL2  = 0;   % the squared two norm term 
                    opts.mFlag = 0;  % treating it as compositive function
                    opts.lFlag  = 0;   % Nemirovski's line search
                    opts.maxIter = 100;
        
% for k=1: K
        tmp=(V0*data);
        tmp=tmp-repmat(mean(tmp)',1,T)';% centrlization
        for j=1:nROI
            y=[tmp(:,j)];
            A=[tmp(:,setdiff(1:nROI,j))];
            [x, funVal1, ValueL1]= LeastR(A, y, lambda, opts);
            currentNet(setdiff(1:nROI,j),j) = x;         
        end
        brainNet=currentNet;
        W_tmp=brainNet;
        S_val=sum(sum(abs(W_tmp)));
        J(1) = (norm(V0*data-V0*data*W_tmp))^2+lambda*S_val;
        currentV=Formula(data,currentNet);
        V0=diag(currentV);
        
    for k=1: K
        tmpk=(V0*data);
        tmpk=tmpk-repmat(mean(tmpk)',1,T)';% centrlization
        for j=1:nROI
            y=[tmpk(:,j)];
            A=[tmpk(:,setdiff(1:nROI,j))];
            [x, funVal1, ValueL1]= LeastR(A, y, lambda, opts);
            currentNet(setdiff(1:nROI,j),j) = x;         
        end
        brainNet=currentNet;
        W_tmpk=brainNet;
        S_val=sum(sum(abs(W_tmpk)));
        J(k+1) = norm(V0*data-V0*data*W_tmpk)^2+lambda*S_val;
%         error=sum(sum(abs(tmpk-tmpk*W_tmpk)));
%         if error<1e-1
%             break
%         else currentV=Formula(data,currentNet);
%             V0=diag(currentV);
%         end
        if abs(J(k+1)- J(k))<1e-3
            break
        else currentV=Formula(data,currentNet);
             V0=diag(currentV);
        end
%         currentV=Formula(data,currentNet);% update V

%         V=V0;
    end
currentV=V0;
