function v=Formula(X,W)


 T=size(X,1);
%v=zeros(T,1);

guodu_v=zeros(T,1);

  for t=1:T
    guodu_v(t)=1/((norm(X(t,:)-X(t,:)*W))^(2));
  end
  for t=1:T
%       v(t)=1-(guodu_v(t)/sum(guodu_v));
      v(t)=guodu_v(t)/sum(guodu_v);
  end
  v;