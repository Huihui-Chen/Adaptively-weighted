clear; clc;
warning off all
root=cd; addpath(genpath([root '/DATA'])); addpath(genpath([root '/FUN']));

load fMRI80; data = fMRImciNc; clear fMRImciNc;

nDegree=size(data{1},1);
nSubj=length(lab);
nROI=size(data{1},2);

ex=-5:5;
lambda=(1/6400)*(2.^ex)
disp('Press any key:'); pause;
nPar=length(lambda);
T=nDegree;
brainNetSet=cell(1,nPar);
brainVSet=cell(1,nPar);

   
    for L=1:nPar
        brainNet=zeros(nROI,nROI,nSubj);
        brainV=zeros(T,T,nSubj);
        for i=1:nSubj
            tmp=data{i}(:,1:nROI);
           [currentNet, currentV] = SoftweightedSR(tmp, lambda(L));
            for k=1:size(currentNet,1)
               for l=1:size(currentNet,2)
                currentNet1(k,l)=sign(currentNet(k,l))*(currentNet(k,l)*currentNet(l,k))^(1/2);   
               end
            end
            brainNet(:,:,i)=currentNet;
            brainV(:,:,i)=currentV;
        end
        brainNetSet{L}=brainNet;
        brainVSet{L}=brainV;
        fprintf('Done %d/%d networks!\n',L,nPar);
    end
    save('SR+W.mat','brainNetSet','lab');
