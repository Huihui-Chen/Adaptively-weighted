function [ currentNet, currentV] = SoftweightedSR(data, lambda)


       [T, nROI] = size(data);
       currentV = zeros(T,1);
       V0 = (1/T)*eye(T);
       K = 100;%��������

       currentNet = zeros(nROI,nROI);
            
                    opts=[];
                    opts.init = 2;
                    opts.tFlag = 5;  % termination criterion
                    opts.nFlag = 0;  % normalization option: 0-without normalization
                    opts.rFlag = 0;   % regularization % the input parameter 'rho' is a ratio in (0, 1)
                    opts.rsL2  = 0;   % the squared two norm term 
                    opts.mFlag = 0;  % treating it as compositive function
                    opts.lFlag  = 0;   % Nemirovski's line search
                    opts.maxIter = 100;
        
% for k=1: K
        tmp=T*(V0*data);
        tmp=tmp-repmat(mean(tmp),T,1);% centrlization
        for j=1:nROI
            y=[tmp(:,j)];
            A=[tmp(:,setdiff(1:nROI,j))];
            [x, funVal1, ValueL1]= LeastR(A, y, lambda, opts);
            currentNet(setdiff(1:nROI,j),j) = x;         
        end
        brainNet=currentNet;
        W_tmp=brainNet;
        S_val=sum(sum(abs(W_tmp)));
        J(1) = (norm(tmp-tmp*W_tmp))^2+lambda*S_val;
        currentV=Formula(data,currentNet);
        V0=diag(currentV);
        
    for k=1: K
        tmpk=T*(V0*data);
        tmpk=tmpk-repmat(mean(tmpk),T,1);% centrlization
        for j=1:nROI
            y=[tmpk(:,j)];
            A=[tmpk(:,setdiff(1:nROI,j))];
            [x, funVal1, ValueL1]= LeastR(A, y, lambda, opts);
            currentNet(setdiff(1:nROI,j),j) = x;         
        end
        brainNet=currentNet;
        W_tmpk=brainNet;
        S_val=sum(sum(abs(W_tmpk)));
        J(k+1) = norm(tmpk-tmpk*W_tmpk)^2+lambda*S_val;

        if abs(J(k+1)- J(k))<1e-3
            break
        else currentV=Formula(data,currentNet);
             V0=diag(currentV);
        end
       
    end
currentV=V0;
